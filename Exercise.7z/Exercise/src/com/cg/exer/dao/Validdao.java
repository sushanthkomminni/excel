package com.cg.exer.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Validdao {
	Connection con=null;
	PreparedStatement ps =null;
	ResultSet rs=null;
	public Connection getConnection() throws Exception
	{
			Class.forName("org.postgresql.Driver");
			String url= "jdbc:postgresql://DIN67000660/test";
			String user = "user";
			String pass = "user";
			con = DriverManager.getConnection(url,user,pass);
			return con;

		
	}	

}
